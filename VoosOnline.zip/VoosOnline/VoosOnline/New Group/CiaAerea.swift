//
//  CiaAerea.swift
//  VoosOnline
//
//  Created by Diego Bueno on 17/02/18.
//  Copyright © 2018 Diego Bueno. All rights reserved.
//

import Foundation

class CiaAerea:CadastroGenerico {
    
    override init(_ codigo:Int, _ nome:String) {
        super.init( codigo,  nome)
    }
        
}
