//
//  CelulaTableViewCell.swift
//  VoosOnline
//
//  Created by Diego Bueno on 03/03/2018.
//  Copyright © 2018 Wellington Antonio. All rights reserved.
//

import UIKit

class CelulaTableViewCell: UITableViewCell {

    
    @IBOutlet weak var vrLabelCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
