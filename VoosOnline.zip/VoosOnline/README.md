# VoosOnline
Projeto academico Swift:


Alunos: 
        Diego Bueno 
        Marcio Pereira
        Giomerito
        Welligton Franco
        


Dados staticos

Cias Aereas:

"LATAM"
"GOL"
"PASSAREDO"
"AVIANCA"
        

Aeroportos:

"GRU"
"CGA"
"GAO"
"GYN"
"BSB"


Voos criados:
1454,
1599,
1598,
4566
1454,
1454  
